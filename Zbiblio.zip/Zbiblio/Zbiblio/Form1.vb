﻿Public Class Lecture
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Dim Jeu1 As Jeu
        Dim datePasFormatee As Date
        Dim dateFormatee As Date
        'datePasFormatee = Me.TextBox1.Text
        dateFormatee = datePasFormatee.ToShortDateString

        Jeu1 = New Jeu("The Division", dateFormatee, "Ubisoft", "TPS, RPG", 17, "Snowdrop")
        'Me.Label1.Text = dateFormatee
    End Sub

    Private Sub Lecture_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.DDL_CHOIX_JEU.SelectedIndex = 0
    End Sub
End Class
