﻿Public Class Jeu
#Region "Attributs"
    Private _nomDuJeu As String
    Private _dateDeSortie As Date
    Private _histoire As String
    Private _developpeur As String
    Private _note As Integer
    Private _genre As String
    Private _moteur As String

#End Region

#Region "Propriétés"
    Private _p1 As String
    Private _p2 As Double
    Private _p3 As Object

    Public Property Nom() As String
        Get
            Return _nomDuJeu
        End Get
        Set(value As String)
            _nomDuJeu = value
        End Set
    End Property

    Public Property DateSortie() As Date
        Get
            Return _dateDeSortie
        End Get
        Set(value As Date)
            _dateDeSortie = value
        End Set
    End Property

    Public Property Histoire() As String
        Get
            Return _histoire
        End Get
        Set(value As String)
            _histoire = value
        End Set
    End Property

    Public Property Developpeur() As String
        Set(value As String)
            _developpeur = value
        End Set
        Get
            Return _developpeur
        End Get
    End Property

    Public Property Note() As Integer
        Get
            Return _note
        End Get
        Set(value As Integer)
            _note = value
        End Set
    End Property

    Public Property Genre() As String
        Get
            Return _genre
        End Get
        Set(value As String)
            _genre = value
        End Set
    End Property

    Public Property Moteur() As String
        Get
            Return _moteur
        End Get
        Set(value As String)
            _moteur = value
        End Set
    End Property

#End Region

#Region "Constructeur"
    Sub New(ByVal nomDuJeu As String, ByVal dateDeSortie As Date, ByVal developpeur As String, ByVal genre As String, ByVal note As Integer, ByVal moteur As String)
        _nomDuJeu = nomDuJeu
        _dateDeSortie = dateDeSortie
        _histoire = Histoire
        _developpeur = developpeur
        _note = note
        _genre = genre
        _moteur = moteur
    End Sub
#End Region
End Class
