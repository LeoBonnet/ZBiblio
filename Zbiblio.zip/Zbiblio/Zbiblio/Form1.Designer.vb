﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Lecture
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DDL_CHOIX_JEU = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'DDL_CHOIX_JEU
        '
        Me.DDL_CHOIX_JEU.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DDL_CHOIX_JEU.FormattingEnabled = True
        Me.DDL_CHOIX_JEU.Items.AddRange(New Object() {"Choisir un jeu"})
        Me.DDL_CHOIX_JEU.Location = New System.Drawing.Point(85, 12)
        Me.DDL_CHOIX_JEU.Name = "DDL_CHOIX_JEU"
        Me.DDL_CHOIX_JEU.Size = New System.Drawing.Size(121, 21)
        Me.DDL_CHOIX_JEU.TabIndex = 0
        '
        'Lecture
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(417, 366)
        Me.Controls.Add(Me.DDL_CHOIX_JEU)
        Me.Name = "Lecture"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DDL_CHOIX_JEU As System.Windows.Forms.ComboBox

End Class
